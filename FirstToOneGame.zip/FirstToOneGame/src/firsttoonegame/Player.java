/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firsttoonegame;

/**
 *
 * @author s-xin.dong
 */
public class Player {
    private int nPlayers;
    private int[] pArray;
    private int winner;
    private int initialP;
    private int point;
    
    public Player(){
        pArray = new int[nPlayers];
    }
    
    public Player(int numberPlayers, int[]player){
        nPlayers = numberPlayers;
        pArray = new int[player.length];
    }
    public void Turn(){
        boolean keepgoing = true;
        Points currentP = new Points();
        while(keepgoing){
            for(int i=0; i<pArray.length; i++){
            System.out.println("This is Player "+ pArray.length + 1 + "turn and the point is now at "+ currentP.getPoints());

        }
        
            
        }
    }

    public void setPoints(int initialP) {
        point = initialP;
    } 
    
    public int getPoints() {
        Die dieGame = new Die(6);

        if (point - dieGame.getValue() > 1) 
            point -= dieGame.getValue();
        
        if (point - dieGame.getValue() < 1) 
            point += dieGame.getValue();
        
        else
            System.out.println("This is the winner!");
              
        return point;
    }
    public int whoWin(){
        return winner;
    }
}
