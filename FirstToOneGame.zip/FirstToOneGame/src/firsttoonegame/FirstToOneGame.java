/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firsttoonegame;

/**
 *
 * @author s-xin.dong
 */
import java.util.Scanner;
public class FirstToOneGame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int startPoints;
        int numberPlayers;
        Scanner keyboard = new Scanner(System.in);
        System.out.print("How many points to start with?");
        startPoints = keyboard.nextInt();
        System.out.print("How many players in this game?");
        numberPlayers = keyboard.nextInt();
        
        Player playing = new Player();
        Points pts = new Points();
        
        playing.Turn();
        pts.getPoints();
        
    }
    
}
