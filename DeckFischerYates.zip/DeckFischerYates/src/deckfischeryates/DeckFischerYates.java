/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deckfischeryates;

import java.util.Random;

/**
 *
 * @author Selena
 */
public class DeckFischerYates {
    
    Card[] cards = new Card[52];
    int topCardIndex = 0;


    /**
     * @param args the command line arguments
     */
    public DeckFischerYates() {
        int index = 0;
        for (Suit s : Suit.values()) {
            for (Rank r : Rank.values()) {
                cards[index++] = new Card(r, s);
            }
        }
    }

    public Card deal() {
        return cards[topCardIndex++];
    }

    public void shuffle() {
        Random rand = new Random();


        // generate two unique indices
        for (int i = 51; i >0; i--) {
            int index = rand.nextInt(i);
            int tmp = 0;
            cards[tmp] = cards[index];
            cards[index] = cards[i];
            cards[i] = cards[tmp];
            // use the two unique indices to 
            // swap two cards in the array

        }

    }

    public static void main(String[] args) {
        // TODO code application logic here

    }

}
