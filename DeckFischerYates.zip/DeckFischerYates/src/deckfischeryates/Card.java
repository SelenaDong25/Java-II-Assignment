/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deckfischeryates;

/**
 *
 * @author Selena
 */
public class Card {
    private Rank rank;
    private Suit suit;
    
    
    public Card (Rank rank, Suit suit) {
        this.rank = rank;
        this.suit = suit;
    }
    
    public Rank getRank() { return this.rank; }
    public Suit getSuit() { return this.suit; }


}