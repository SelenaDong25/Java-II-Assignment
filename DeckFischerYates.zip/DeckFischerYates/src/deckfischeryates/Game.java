/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deckfischeryates;

/**
 *
 * @author Selena
 */
public class Game {
    public static void main( String[] args ) {
        DeckFischerYates deck = new DeckFischerYates();
        deck.shuffle();
        
        System.out.println(deck);
        Card c = deck.deal();
        
        // deck.shuffle();
        // deck.cut();
        
        // create players
        // deal cards to the players
    }
}
