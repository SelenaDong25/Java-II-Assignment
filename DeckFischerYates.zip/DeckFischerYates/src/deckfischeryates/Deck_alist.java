/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deckfischeryates;

import java.util.Random;
import java.util.ArrayList;

/**
 *
 * @author Selena
 */
public class Deck_alist {
    Card[] cards = new Card[52];
    int topCardIndex = 0;

    public Deck_alist() {
        int index = 0;
        for (Suit s : Suit.values()) {
            for (Rank r : Rank.values()) {
                cards[index++] = new Card(r, s);
            }
        }
    }

    public Card deal() {
        return cards[topCardIndex++];
    }

    public void shuffle() {
        Random rand = new Random();
        int left = 0, right = 0;

        int maxLoopCt = cards.length * 10;

        // generate two unique indices
        for (int i = 0; i < maxLoopCt; i++) {
            left = rand.nextInt(52);
            do {
                right = rand.nextInt(52);
            } while (left == right);

            // use the two unique indices to 
            // swap two cards in the array
            Card tmp = cards[left];
            cards[left] = cards[right];
            cards[right] = tmp;
        }

    }
}
    